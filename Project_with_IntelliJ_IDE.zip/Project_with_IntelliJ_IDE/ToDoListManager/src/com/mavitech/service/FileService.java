package com.mavitech.service;

import com.mavitech.model.Task;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles the loading and saving of Task objects to a file using Java Serialization.
 */
public class FileService {

    private final String filePath;

    /**
     * Constructs a FileService with the specified file path.
     *
     * @param filePath The path to the file where tasks will be stored.
     */
    public FileService(String filePath) {
        this.filePath = filePath;
        // Ensure the directory exists
        File file = new File(filePath);
        File parentDir = file.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs(); // Create necessary directories
        }
    }

    /**
     * Loads a list of tasks from the configured file.
     *
     * @return A List of Task objects loaded from the file, or an empty ArrayList if the file doesn't exist
     * or an error occurs during loading.
     */
    public List<Task> loadTasks() {
        List<Task> tasks = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(filePath);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            // Read the object from the file, casting it to List<Task>
            Object obj = ois.readObject();
            if (obj instanceof List) {
                // Safely cast the object to a List of Task
                tasks = (List<Task>) obj;
                System.out.println("Tasks loaded successfully from " + filePath);
            } else {
                System.err.println("Warning: Data in file is not a List<Task>. Starting with empty list.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("No existing tasks file found at " + filePath + ". Starting with an empty list.");
        } catch (IOException e) {
            System.err.println("Error reading tasks from file: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.err.println("Error: Class not found during deserialization. " + e.getMessage());
        } catch (ClassCastException e) {
            System.err.println("Error: Data in file is not compatible with Task list. " + e.getMessage());
        }
        return tasks;
    }

    /**
     * Saves a list of tasks to the configured file.
     *
     * @param tasks The List of Task objects to be saved.
     */
    public void saveTasks(List<Task> tasks) {
        try (FileOutputStream fos = new FileOutputStream(filePath);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            // Write the list of tasks to the file
            oos.writeObject(tasks);
            System.out.println("Tasks saved successfully to " + filePath);
        } catch (IOException e) {
            System.err.println("Error saving tasks to file: " + e.getMessage());
        }
    }
}
