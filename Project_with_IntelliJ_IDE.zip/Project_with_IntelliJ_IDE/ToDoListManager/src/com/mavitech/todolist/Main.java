package com.mavitech.todolist;

import com.mavitech.controller.TaskController;
import com.mavitech.gui.ToDoListGUI; // Import the new GUI class

import javax.swing.*;
// import com.mavitech.ui.ConsoleUI; // Comment out or remove this line

public class Main {
    public static void main(String[] args) {
        // Create the controller
        TaskController controller = new TaskController();

        // Create and show the GUI
        // Use SwingUtilities.invokeLater to ensure GUI updates are done on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            ToDoListGUI gui = new ToDoListGUI(controller);
            gui.setVisible(true); // Make the GUI window visible
        });

        // The ConsoleUI is no longer needed for the GUI version
        // ConsoleUI ui = new ConsoleUI(controller);
        // ui.start();
    }
}
