package com.mavitech.gui;

import com.mavitech.controller.TaskController;
import com.mavitech.model.Task;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

/**
 * Provides a graphical user interface (GUI) for the To-Do List application
 * using Java Swing. It interacts with the TaskController to manage tasks.
 */
public class ToDoListGUI extends JFrame {

    private final TaskController controller;
    private DefaultListModel<Task> taskListModel; // Model for the JList to hold Task objects
    private JList<Task> taskList; // Displays the list of tasks
    private JTextField taskInputField; // Input field for new task descriptions

    /**
     * Constructs the ToDoListGUI.
     *
     * @param controller The TaskController instance to interact with.
     */
    public ToDoListGUI(TaskController controller) {
        this.controller = controller;
        setTitle("To-Do List Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close operation for the frame
        setSize(500, 600); // Initial size of the window
        setLocationRelativeTo(null); // Center the window on the screen

        initComponents(); // Initialize GUI components
        loadTasksIntoList(); // Load existing tasks when the GUI starts
    }

    /**
     * Initializes all the GUI components and sets up their layout and event listeners.
     */
    private void initComponents() {
        // Set a BorderLayout for the main frame content pane
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout(10, 10)); // Add some padding between regions
        ((JComponent) contentPane).setBorder(new EmptyBorder(10, 10, 10, 10)); // Overall padding

        // --- Top Panel: Add New Task ---
        JPanel inputPanel = new JPanel(new BorderLayout(5, 5));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Add New Task"));
        taskInputField = new JTextField();
        taskInputField.setFont(new Font("SansSerif", Font.PLAIN, 16));
        taskInputField.addActionListener(e -> addTask()); // Add task on Enter key press

        JButton addButton = new JButton("Add Task");
        addButton.setFont(new Font("SansSerif", Font.BOLD, 14));
        addButton.setBackground(new Color(92, 184, 92)); // Green color
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false); // Remove focus border
        addButton.addActionListener(e -> addTask());

        inputPanel.add(taskInputField, BorderLayout.CENTER);
        inputPanel.add(addButton, BorderLayout.EAST);
        contentPane.add(inputPanel, BorderLayout.NORTH);

        // --- Center Panel: Task List ---
        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        taskList.setFont(new Font("SansSerif", Font.PLAIN, 16));
        taskList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Allow only single selection
        // Custom renderer to display tasks with checkboxes
        taskList.setCellRenderer(new ToDoListCellRenderer());

        JScrollPane scrollPane = new JScrollPane(taskList);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Your Tasks"));
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // --- Bottom Panel: Action Buttons ---
        JPanel buttonPanel = new JPanel(new GridLayout(1, 4, 10, 0)); // 1 row, 4 columns, 10px horizontal gap
        buttonPanel.setBorder(new EmptyBorder(10, 0, 0, 0)); // Padding above buttons

        JButton markCompletedButton = new JButton("Mark Completed");
        markCompletedButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        markCompletedButton.setBackground(new Color(66, 139, 202)); // Blue color
        markCompletedButton.setForeground(Color.WHITE);
        markCompletedButton.setFocusPainted(false);
        markCompletedButton.addActionListener(e -> markTaskCompleted());

        JButton editButton = new JButton("Edit Task");
        editButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        editButton.setBackground(new Color(240, 173, 78)); // Orange color
        editButton.setForeground(Color.WHITE);
        editButton.setFocusPainted(false);
        editButton.addActionListener(e -> editTask());

        JButton removeButton = new JButton("Remove Task");
        removeButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        removeButton.setBackground(new Color(217, 83, 79)); // Red color
        removeButton.setForeground(Color.WHITE);
        removeButton.setFocusPainted(false);
        removeButton.addActionListener(e -> removeTask());

        JButton clearAllButton = new JButton("Clear All");
        clearAllButton.setFont(new Font("SansSerif", Font.BOLD, 12));
        clearAllButton.setBackground(new Color(91, 192, 222)); // Light blue color
        clearAllButton.setForeground(Color.WHITE);
        clearAllButton.setFocusPainted(false);
        clearAllButton.addActionListener(e -> clearAllTasks());

        buttonPanel.add(markCompletedButton);
        buttonPanel.add(editButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(clearAllButton);
        contentPane.add(buttonPanel, BorderLayout.SOUTH);
    }

    /**
     * Loads tasks from the controller into the JList model.
     */
    private void loadTasksIntoList() {
        taskListModel.clear(); // Clear existing items in the model
        List<Task> tasks = controller.getTasks();
        for (Task task : tasks) {
            taskListModel.addElement(task); // Add each task to the model
        }
    }

    /**
     * Adds a new task based on the text in the input field.
     */
    private void addTask() {
        String description = taskInputField.getText().trim();
        if (description.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Task description cannot be empty.", "Input Error", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Task newTask = new Task(description);
        controller.addTask(newTask);
        loadTasksIntoList(); // Refresh the list
        taskInputField.setText(""); // Clear the input field
        JOptionPane.showMessageDialog(this, "Task added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Marks the selected task as completed or uncompleted.
     */
    private void markTaskCompleted() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select a task to mark.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Task selectedTask = taskListModel.getElementAt(selectedIndex);
        selectedTask.setCompleted(!selectedTask.isCompleted()); // Toggle completion status
        controller.updateTask(selectedIndex, selectedTask); // Update in controller
        loadTasksIntoList(); // Refresh the list to show updated status
        JOptionPane.showMessageDialog(this, "Task completion status updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Allows editing the description of the selected task.
     */
    private void editTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select a task to edit.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Task originalTask = taskListModel.getElementAt(selectedIndex);
        String currentDescription = originalTask.getDescription();
        String newDescription = JOptionPane.showInputDialog(this,
                "Edit task description:",
                "Edit Task",
                JOptionPane.QUESTION_MESSAGE,
                null,
                null,
                currentDescription).toString();

        if (newDescription != null && !newDescription.trim().isEmpty()) {
            originalTask.setDescription(newDescription.trim());
            controller.updateTask(selectedIndex, originalTask);
            loadTasksIntoList(); // Refresh the list
            JOptionPane.showMessageDialog(this, "Task updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else if (newDescription != null) { // User entered empty string
            JOptionPane.showMessageDialog(this, "Task description cannot be empty.", "Input Error", JOptionPane.WARNING_MESSAGE);
        }
        // If newDescription is null, user cancelled the input dialog, so do nothing.
    }

    /**
     * Removes the selected task from the list.
     */
    private void removeTask() {
        int selectedIndex = taskList.getSelectedIndex();
        if (selectedIndex == -1) {
            JOptionPane.showMessageDialog(this, "Please select a task to remove.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to remove the selected task?",
                "Confirm Removal",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (controller.removeTask(selectedIndex)) {
                loadTasksIntoList(); // Refresh the list
                JOptionPane.showMessageDialog(this, "Task removed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to remove task.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Clears all tasks from the list after user confirmation.
     */
    private void clearAllTasks() {
        if (controller.getTaskCount() == 0) {
            JOptionPane.showMessageDialog(this, "No tasks to clear.", "Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to clear ALL tasks?",
                "Confirm Clear All",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            controller.clearTasks();
            loadTasksIntoList(); // Refresh the list (it will become empty)
            JOptionPane.showMessageDialog(this, "All tasks cleared!", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    /**
     * Custom ListCellRenderer to display Task objects with a JCheckBox.
     * This allows tasks to visually represent their completion status.
     */
    private class ToDoListCellRenderer extends JCheckBox implements ListCellRenderer<Task> {
        public ToDoListCellRenderer() {
            setOpaque(true); // Ensure the background is painted
            setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5)); // Add some padding
            setFont(new Font("SansSerif", Font.PLAIN, 16));
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends Task> list, Task task, int index,
                                                      boolean isSelected, boolean cellHasFocus) {
            setText(task.getDescription()); // Set the task description as text
            setSelected(task.isCompleted()); // Set checkbox state based on task completion

            // Handle selection colors
            if (isSelected) {
                setBackground(list.getSelectionBackground());
                setForeground(list.getSelectionForeground());
            } else {
                setBackground(list.getBackground());
                setForeground(list.getForeground());
            }
            return this;
        }
    }
}
