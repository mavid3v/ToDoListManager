package com.mavitech.ui;

import com.mavitech.controller.TaskController;
import com.mavitech.model.Task;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 * Provides a console-based user interface for the To-Do List application.
 * It interacts with the TaskController to perform operations.
 */
public class ConsoleUI {

    private final TaskController controller;
    private final Scanner scanner;

    /**
     * Constructs a ConsoleUI with a reference to the TaskController.
     *
     * @param controller The TaskController instance to interact with.
     */
    public ConsoleUI(TaskController controller) {
        this.controller = controller;
        this.scanner = new Scanner(System.in);
    }

    /**
     * Starts the main loop of the console UI, displaying the menu and processing user input.
     */
    public void start() {
        System.out.println("Welcome to the To-Do List Application!");
        int choice;
        do {
            displayMenu();
            choice = getUserChoice();

            switch (choice) {
                case 1:
                    addTask();
                    break;
                case 2:
                    viewTasks();
                    break;
                case 3:
                    markTaskCompleted();
                    break;
                case 4:
                    editTask();
                    break;
                case 5:
                    removeTask();
                    break;
                case 6:
                    clearAllTasks();
                    break;
                case 0:
                    System.out.println("Exiting To-Do List. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
            System.out.println(); // Add a newline for better readability between operations
        } while (choice != 0);
        scanner.close(); // Close the scanner when the application exits
    }

    /**
     * Displays the main menu options to the user.
     */
    private void displayMenu() {
        System.out.println("--- To-Do List Menu ---");
        System.out.println("1. Add Task");
        System.out.println("2. View Tasks");
        System.out.println("3. Mark Task as Completed");
        System.out.println("4. Edit Task");
        System.out.println("5. Remove Task");
        System.out.println("6. Clear All Tasks");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    /**
     * Prompts the user for a menu choice and returns it. Handles invalid input.
     *
     * @return The integer choice entered by the user.
     */
    private int getUserChoice() {
        try {
            return scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // Consume the invalid input
            return -1; // Return an invalid choice to re-display menu
        } finally {
            scanner.nextLine(); // Consume the rest of the line after reading the integer
        }
    }

    /**
     * Prompts the user for a task description and adds it using the controller.
     */
    private void addTask() {
        System.out.print("Enter task description: ");
        String description = scanner.nextLine();
        if (description.trim().isEmpty()) {
            System.out.println("Task description cannot be empty.");
            return;
        }
        controller.addTask(new Task(description));
        System.out.println("Task added successfully!");
    }

    /**
     * Displays all tasks currently in the list.
     */
    private void viewTasks() {
        List<Task> tasks = controller.getTasks();
        if (tasks.isEmpty()) {
            System.out.println("No tasks in the list.");
            return;
        }
        System.out.println("--- Your Tasks ---");
        for (int i = 0; i < tasks.size(); i++) {
            System.out.println((i + 1) + ". " + tasks.get(i));
        }
    }

    /**
     * Prompts the user for a task index and marks it as completed.
     */
    private void markTaskCompleted() {
        viewTasks(); // Show tasks first
        if (controller.getTaskCount() == 0) {
            return; // No tasks to mark
        }
        System.out.print("Enter the number of the task to mark as completed: ");
        int index = getTaskIndexFromUser();
        if (index != -1) {
            List<Task> tasks = controller.getTasks();
            if (index < tasks.size()) {
                Task taskToUpdate = tasks.get(index);
                if (!taskToUpdate.isCompleted()) {
                    taskToUpdate.setCompleted(true);
                    controller.updateTask(index, taskToUpdate);
                    System.out.println("Task marked as completed!");
                } else {
                    System.out.println("Task is already completed.");
                }
            } else {
                System.out.println("Invalid task number.");
            }
        }
    }

    /**
     * Prompts the user for a task index and allows them to edit its description.
     */
    private void editTask() {
        viewTasks(); // Show tasks first
        if (controller.getTaskCount() == 0) {
            return; // No tasks to edit
        }
        System.out.print("Enter the number of the task to edit: ");
        int index = getTaskIndexFromUser();
        if (index != -1) {
            List<Task> tasks = controller.getTasks();
            if (index < tasks.size()) {
                Task originalTask = tasks.get(index);
                System.out.println("Current description: " + originalTask.getDescription());
                System.out.print("Enter new description (leave blank to keep current): ");
                String newDescription = scanner.nextLine();

                if (!newDescription.trim().isEmpty()) {
                    originalTask.setDescription(newDescription.trim());
                    controller.updateTask(index, originalTask);
                    System.out.println("Task updated successfully!");
                } else {
                    System.out.println("No changes made to the task description.");
                }
            } else {
                System.out.println("Invalid task number.");
            }
        }
    }

    /**
     * Prompts the user for a task index and removes it using the controller.
     */
    private void removeTask() {
        viewTasks(); // Show tasks first
        if (controller.getTaskCount() == 0) {
            return; // No tasks to remove
        }
        System.out.print("Enter the number of the task to remove: ");
        int index = getTaskIndexFromUser();
        if (index != -1) {
            if (controller.removeTask(index)) {
                System.out.println("Task removed successfully!");
            } else {
                System.out.println("Invalid task number.");
            }
        }
    }

    /**
     * Clears all tasks from the list after user confirmation.
     */
    private void clearAllTasks() {
        if (controller.getTaskCount() == 0) {
            System.out.println("No tasks to clear.");
            return;
        }
        System.out.print("Are you sure you want to clear all tasks? (yes/no): ");
        String confirmation = scanner.nextLine().trim().toLowerCase();
        if (confirmation.equals("yes")) {
            controller.clearTasks();
            System.out.println("All tasks cleared!");
        } else {
            System.out.println("Operation cancelled.");
        }
    }

    /**
     * Helper method to get a valid task index from user input.
     *
     * @return The 0-based index of the task, or -1 if input is invalid.
     */
    private int getTaskIndexFromUser() {
        try {
            int taskNumber = scanner.nextInt();
            if (taskNumber > 0 && taskNumber <= controller.getTaskCount()) {
                return taskNumber - 1; // Convert to 0-based index
            } else {
                System.out.println("Task number out of range.");
                return -1;
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
            return -1;
        } finally {
            scanner.nextLine(); // Consume the rest of the line
        }
    }
}
