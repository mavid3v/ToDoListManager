package com.mavitech.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Represents a single task in the To-Do list.
 * Implements Serializable to allow saving and loading objects to/from a file.
 */
public class Task implements Serializable {
    // Unique identifier for serialization. Recommended for Serializable classes.
    private static final long serialVersionUID = 1L;

    private String description;
    private boolean isCompleted;

    /**
     * Constructs a new Task with the given description.
     * By default, a new task is not completed.
     *
     * @param description The description of the task.
     */
    public Task(String description) {
        this.description = description;
        this.isCompleted = false; // New tasks are not completed by default
    }

    /**
     * Gets the description of the task.
     *
     * @return The task description.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the description of the task.
     *
     * @param description The new description for the task.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Checks if the task is completed.
     *
     * @return true if the task is completed, false otherwise.
     */
    public boolean isCompleted() {
        return isCompleted;
    }

    /**
     * Sets the completion status of the task.
     *
     * @param completed true to mark the task as completed, false to mark it as not completed.
     */
    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    /**
     * Overrides the toString method to provide a user-friendly representation of the task.
     *
     * @return A string representation of the task, including its completion status and description.
     */
    @Override
    public String toString() {
        return (isCompleted ? "[X] " : "[ ] ") + description;
    }

    /**
     * Overrides the equals method to compare Task objects based on their description and completion status.
     *
     * @param o The object to compare with.
     * @return true if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return isCompleted == task.isCompleted &&
                Objects.equals(description, task.description);
    }

    /**
     * Overrides the hashCode method, consistent with the equals method.
     *
     * @return The hash code for this Task object.
     */
    @Override
    public int hashCode() {
        return Objects.hash(description, isCompleted);
    }
}
