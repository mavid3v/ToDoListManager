package com.mavitech.controller;

import com.mavitech.model.Task;
import com.mavitech.service.FileService;

import java.util.ArrayList;
import java.util.List;

public class TaskController {

    private final List<Task> tasks;
    private final FileService fileService;

    public TaskController() {
        fileService = new FileService("data/tasks.dat");
        tasks = fileService.loadTasks();
    }

    // Add a new task
    public void addTask(Task task) {
        tasks.add(task);
        fileService.saveTasks(tasks);
    }

    // Remove a task by index
    public boolean removeTask(int index) {
        if (index >= 0 && index < tasks.size()) {
            tasks.remove(index);
            fileService.saveTasks(tasks);
            return true;
        }
        return false;
    }

    // Edit a task at index
    public boolean updateTask(int index, Task updatedTask) {
        if (index >= 0 && index < tasks.size()) {
            tasks.set(index, updatedTask);
            fileService.saveTasks(tasks);
            return true;
        }
        return false;
    }

    // Get all tasks
    public List<Task> getTasks() {
        return new ArrayList<>(tasks); // Return a copy
    }

    // Get task count
    public int getTaskCount() {
        return tasks.size();
    }

    // Clear all tasks
    public void clearTasks() {
        tasks.clear();
        fileService.saveTasks(tasks);
    }
}
